package designpatterns.strategy;

public interface AverageScoreStrategy {
    /**
     */
    void calculateAvgScore();
}

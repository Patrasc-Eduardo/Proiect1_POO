package DesignPatterns;

public interface AverageScoreStrategy {
    void calculateAvgScore();
}
